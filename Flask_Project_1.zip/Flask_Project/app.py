from flask import Flask, request

app = Flask(__name__)

@app.route('/')
def home():
    name = request.args.get('name')
    if name:
        return f"Hello, {name.upper()}!"
    return "Use ?name=yourname"

@app.route('/reverse')
def reverse():
    name = request.args.get('name')
    if name:
        return f"Reverse: {name[::-1]}"
    return "Provide name"

@app.route('/length')
def length():
    name = request.args.get('name')
    if name:
        return f"Length: {len(name)}"
    return "Provide name"

@app.route('/funny')
def funny():
    name = request.args.get('name')
    if name:
        return f"{name.upper()} 😂🔥 IS AWESOME!"
    return "Provide name"

@app.route('/style')
def style():
    name = request.args.get('name')
    if name:
        return f"""
        <h1 style='color:green;'>Hello {name.upper()}</h1>
        <p>Welcome to your Flask App 🚀</p>
        """
    return "Provide name"

if __name__ == '__main__':
    app.run(debug=True)